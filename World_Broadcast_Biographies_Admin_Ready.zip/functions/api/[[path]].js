const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}

function envValue(env, key) {
  const value = env[key];
  if (!value) throw new Error(`Missing server setting: ${key}`);
  return value;
}

async function requireAdmin(request, env) {
  const auth = request.headers.get("Authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return null;

  const url = envValue(env, "SUPABASE_URL").replace(/\/$/, "");
  const anon = envValue(env, "SUPABASE_ANON_KEY");
  const response = await fetch(`${url}/auth/v1/user`, {
    headers: { apikey: anon, Authorization: `Bearer ${token}` }
  });
  if (!response.ok) return null;

  const user = await response.json();
  const allowedEmail = (env.ADMIN_EMAIL || "").trim().toLowerCase();
  if (!user.email || user.email.toLowerCase() !== allowedEmail) return null;
  return user;
}

async function dbRequest(env, path, options = {}) {
  const url = envValue(env, "SUPABASE_URL").replace(/\/$/, "");
  const key = envValue(env, "SUPABASE_SERVICE_ROLE_KEY");
  const response = await fetch(`${url}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "content-type": "application/json",
      ...(options.headers || {})
    }
  });
  const body = await response.text();
  if (!response.ok) {
    return { ok: false, status: response.status, body };
  }
  return { ok: true, status: response.status, body };
}

async function uploadImage(request, env) {
  const user = await requireAdmin(request, env);
  if (!user) return json({ error: "Unauthorized" }, 401);

  const form = await request.formData();
  const file = form.get("image");
  if (!(file instanceof File)) return json({ error: "Image file is required" }, 400);
  if (file.size > 2 * 1024 * 1024) return json({ error: "Image must be 2 MB or smaller" }, 400);

  const allowed = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp"
  };
  const ext = allowed[file.type];
  if (!ext) return json({ error: "Use JPG, PNG, or WEBP image" }, 400);

  const url = envValue(env, "SUPABASE_URL").replace(/\/$/, "");
  const key = envValue(env, "SUPABASE_SERVICE_ROLE_KEY");
  const objectPath = `${crypto.randomUUID()}.${ext}`;
  const uploadUrl = `${url}/storage/v1/object/biography-images/${objectPath}`;
  const upload = await fetch(uploadUrl, {
    method: "POST",
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": file.type,
      "x-upsert": "false"
    },
    body: file.stream()
  });
  if (!upload.ok) return json({ error: "Image upload failed" }, 502);

  return json({
    image_url: `${url}/storage/v1/object/public/biography-images/${objectPath}`
  });
}

export async function onRequest(context) {
  const { request, env, params } = context;
  const path = Array.isArray(params.path) ? params.path.join("/") : String(params.path || "");
  const method = request.method.toUpperCase();

  try {
    if (path === "biographies" && method === "GET") {
      const result = await dbRequest(
        env,
        "biographies?select=id,title,person_name,role,country,biography,linkedin_url,image_url,sources,published_at&is_published=eq.true&order=published_at.desc"
      );
      if (!result.ok) return json({ error: "Could not load biographies" }, 502);
      return new Response(result.body, {
        headers: { ...JSON_HEADERS, "cache-control": "public, max-age=60" }
      });
    }

    if (path === "upload" && method === "POST") {
      return await uploadImage(request, env);
    }

    if (path === "biographies" && method === "POST") {
      const user = await requireAdmin(request, env);
      if (!user) return json({ error: "Unauthorized" }, 401);

      const data = await request.json();
      const required = ["title", "person_name", "biography"];
      if (required.some(k => !String(data[k] || "").trim())) {
        return json({ error: "Title, professional name, and biography are required" }, 400);
      }

      const record = {
        title: String(data.title).trim(),
        person_name: String(data.person_name).trim(),
        role: String(data.role || "").trim(),
        country: String(data.country || "").trim(),
        biography: String(data.biography).trim(),
        linkedin_url: String(data.linkedin_url || "").trim(),
        image_url: String(data.image_url || "").trim(),
        sources: String(data.sources || "").trim(),
        is_published: true,
        published_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      const result = await dbRequest(env, "biographies", {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify(record)
      });
      if (!result.ok) return json({ error: "Could not publish biography" }, 502);
      return new Response(result.body, { status: 201, headers: JSON_HEADERS });
    }

    if (path.startsWith("biographies/") && method === "DELETE") {
      const user = await requireAdmin(request, env);
      if (!user) return json({ error: "Unauthorized" }, 401);
      const id = path.slice("biographies/".length);
      if (!/^[0-9a-f-]{36}$/i.test(id)) return json({ error: "Invalid ID" }, 400);
      const result = await dbRequest(env, `biographies?id=eq.${id}`, { method: "DELETE" });
      if (!result.ok) return json({ error: "Could not delete biography" }, 502);
      return json({ success: true });
    }

    return json({ error: "Not found" }, 404);
  } catch (error) {
    return json({ error: error.message || "Server error" }, 500);
  }
}
