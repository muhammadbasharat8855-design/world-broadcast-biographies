// Public browser configuration only.
// Replace these two placeholders with the Supabase Project URL and anon/publishable key.
// NEVER put the Supabase service_role key in this file.
window.WBB_CONFIG = {
  supabaseUrl: "PASTE_SUPABASE_PROJECT_URL_HERE",
  supabaseAnonKey: "PASTE_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE"
};
