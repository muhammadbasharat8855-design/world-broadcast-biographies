create extension if not exists pgcrypto;

create table if not exists public.biographies (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  person_name text not null,
  role text not null default '',
  country text not null default '',
  biography text not null,
  linkedin_url text not null default '',
  image_url text not null default '',
  sources text not null default '',
  is_published boolean not null default true,
  published_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.biographies enable row level security;

-- No direct browser policies are created.
-- All database reads/writes go through the Cloudflare server function.
-- Keep the Supabase service role key only in Cloudflare Secrets.
