// Supabase project URL and anon/public key only. Never put service_role keys here.
window.WBB_CONFIG = {
  SUPABASE_URL: "PASTE_PROJECT_URL",
  SUPABASE_ANON_KEY: "PASTE_ANON_PUBLIC_KEY"
};
