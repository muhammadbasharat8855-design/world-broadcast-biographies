-- Run in Supabase SQL Editor. Replace ADMIN_UUID with your Supabase Auth user's UUID.
create extension if not exists pgcrypto;
create table if not exists public.biographies (
 id uuid primary key default gen_random_uuid(), name text not null, role text not null,
 country text, category text, summary text not null, biography text not null,
 linkedin_url text, source_urls text[] not null default '{}', image_url text,
 published boolean not null default false, created_by uuid not null references auth.users(id),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
alter table public.biographies enable row level security;
create policy "Public read published" on public.biographies for select using (published = true);
create policy "Admin read all" on public.biographies for select to authenticated using (auth.uid() = 'ADMIN_UUID'::uuid);
create policy "Admin insert" on public.biographies for insert to authenticated with check (auth.uid() = 'ADMIN_UUID'::uuid and created_by = auth.uid());
create policy "Admin update" on public.biographies for update to authenticated using (auth.uid() = 'ADMIN_UUID'::uuid) with check (auth.uid() = 'ADMIN_UUID'::uuid);
create policy "Admin delete" on public.biographies for delete to authenticated using (auth.uid() = 'ADMIN_UUID'::uuid);
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('biography-photos','biography-photos',true,2097152,array['image/jpeg','image/png','image/webp']) on conflict (id) do nothing;
create policy "Public view biography photos" on storage.objects for select using (bucket_id='biography-photos');
create policy "Admin upload biography photos" on storage.objects for insert to authenticated with check (bucket_id='biography-photos' and auth.uid()='ADMIN_UUID'::uuid and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Admin update biography photos" on storage.objects for update to authenticated using (bucket_id='biography-photos' and auth.uid()='ADMIN_UUID'::uuid);
create policy "Admin delete biography photos" on storage.objects for delete to authenticated using (bucket_id='biography-photos' and auth.uid()='ADMIN_UUID'::uuid);
